public abstract class Account
{
	
	protected int accountNumber;
	protected double balance;
	
	 
    public abstract void setAccountNumber(int accountNumber);
    public abstract void setBalance(double balance);
    public abstract int getAccountNumber();
    public abstract double getBalance();
    public abstract void showInfo();
}