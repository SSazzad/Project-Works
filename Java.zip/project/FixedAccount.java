public class FixedAccount 
{
	
	

}