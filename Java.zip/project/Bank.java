public class Bank
{
	public Customer customers[];
    public Employee employees[];

}