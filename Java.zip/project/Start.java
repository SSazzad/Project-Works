public class Start
{
public static void main(String [] args)

  {
	System.out.println("on going ");
	
  }
}