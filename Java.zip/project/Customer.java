public class Customer
{
   private String name;
   private int nid;
   private Account accounts[];



}