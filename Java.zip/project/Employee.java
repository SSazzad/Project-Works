public class Employee
{
	private String name;
    private String empId;
    private double salary;
}