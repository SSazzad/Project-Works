﻿using MyCoffeeProject.Classes;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using MyCoffeeProject.Classes.Derived_Coffee_Drinks;
using System.IO;

namespace MyCoffeeProject
{

    public partial class YodaCoffeeShop : Form //need partial. WHY?
    {
       // 'public List<Customer> YodaCustomerList = new List<Customer>;
      
        ArrayList yodaCustomerList = new ArrayList();
        ArrayList coffeesOrdered = new ArrayList();
        public YodaCoffeeShop()
        {
            InitializeComponent();

        }

        private void saveCustBtn_Click(object sender, EventArgs e)
        {
            //TODO
            //look into why i cant use a variable 

            //private string fName;
            //private string lName;
            //private string pNumber;
            //private string fCoffee;

            //private string fName = fNametextBox.Text;
            //string fName = fNametextBox.Text;
            //string fName = fNametextBox.Text;
            //string fName = fNametextBox.Text;

            Customer YodasCustomer = new Customer(fNametextBox.Text, lastNametextBox.Text, phoneNumtextBox.Text, favCoffeeTxtBox.Text) ;

            //add customer to list
            yodaCustomerList.Add(YodasCustomer);
            
        }

        private void displayCustBtn_Click(object sender, EventArgs e)
        {
            foreach (Customer cust in yodaCustomerList)
            {
                outputListBox.Items.Add(cust.DisplayCustomer()); //add customer obj in string form
                outPutLabel.Text = cust.DisplayCustomer();//display the customer object as string form
            }           
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        #region Clear All Method
        private void ClearAll()
        {
            fNametextBox.Text = "";
            lastNametextBox.Text = "";
            phoneNumtextBox.Text = "";
            favCoffeeTxtBox.Text = "";

            outPutLabel.Text = string.Empty;
            //clear the list box
            outputListBox.Items.Clear();

            priceLabel.Text = "Price:";

            smRadioBtn.Checked = false;
            medRadioBtn.Checked = false;
            lgRadioBtn.Checked = false;

            icedCoffeeRdBtn.Checked = false;
            icedLatteRdBtn.Checked = false;
        }
        #endregion

        #region Calculate Cost Button Click
        private void calcCostBtn_Click(object sender, EventArgs e)
        { 
            var buttons = this.Controls.OfType<RadioButton>().FirstOrDefault(n => n.Checked);

           
            string iceamt = "normal";
            string size;
            double bill;

            if (icedCoffeeRdBtn.Checked == true)
            {
                string bTime = "long";
                

                if (smRadioBtn.Checked == true)
                {
                    size = "Small";
                    bill = 50;
                }
                else if (medRadioBtn.Checked == true)
                {
                    size = "Medium";
                    bill = 150;
                }
                else
                {
                    size = "Large";
                       bill = 200;
                }
                //create new Iced Coffee object
                IcedCoffee custsCoffee = new IcedCoffee(size,bTime, iceamt, bill  );
                //Set Price
                priceLabel.Text = "Price: " + custsCoffee.price.ToString("C2");
                //Add object to list
                coffeesOrdered.Add(custsCoffee);
                //Count total
                ttlCoffeesLabel.Text = "Total:" + coffeesOrdered.Capacity.ToString();
            }
            else if (icedLatteRdBtn.Checked == true)
            {
                string bTime = "short";
                string icea = "normal";
                string milkAmount = "normal";
                double bill1;


                if (smRadioBtn.Checked == true)
                {
                    size = "Small";
                    bill1 = 100;
                }
                else if (medRadioBtn.Checked == true)
                {
                    size = "Medium";
                    bill1 = 200;
                }
                else
                {
                    size = "Large";
                    bill1 = 300;
                }

                //create new Iced Latte object
                IcedLatte custsCoffee = new IcedLatte(size, bTime, icea, milkAmount, bill1);
                //Set Price
                priceLabel.Text = "Price: " + custsCoffee.price.ToString("C2");

                //Add object to list
                coffeesOrdered.Add(custsCoffee); //TODO wrong
                //Count total
                ttlCoffeesLabel.Text = "Total:" + coffeesOrdered.Capacity.ToString();
            }

           // CoffeeDrinks customersCoffee = new CoffeeDrinks();     
        }
        #endregion

      

        //need to define and use the hello () because I impllement the interface at top of the program
        

        private void icedCoffeeRdBtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void headerLabel_Click(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Text Documents|*.txt", ValidateNames = true })
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName))
                    {

                        await sw.WriteLineAsync("Name:"+fNametextBox.Text);
                        await sw.WriteLineAsync("Order No:"+lastNametextBox.Text);
                        await sw.WriteLineAsync("Order coffee:" + favCoffeeTxtBox.Text);
                        await sw.WriteLineAsync("Bill:"+phoneNumtextBox.Text);
                       
                        MessageBox.Show("saved", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
        }

        private void YodaCoffeeShop_Load(object sender, EventArgs e)
        {

        }

        private void welcomeLabel_Click(object sender, EventArgs e)
        {

        }

        private void medRadioBtn_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
