﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;

namespace MyCoffeeProject
{
    public partial class Form1 : Form
    {
        

        private DataAccess Da { get; set; }
        private DataSet Ds { get; set; }

        DataTable dt = new DataTable();

        public Form1()
        {
            InitializeComponent();
            this.Da = new DataAccess();


        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L73G6O4\SQLEXPRESS;Initial Catalog=coffeeshop;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT(*) FROM admininfo WHERE username='" + txt_user.Text + "' AND password='" + txt_pass.Text + "'", con);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {

                this.Hide();
                new YodaCoffeeShop().Show();
            }
            else
                MessageBox.Show("Invalid username or password");
        }
    }
}
