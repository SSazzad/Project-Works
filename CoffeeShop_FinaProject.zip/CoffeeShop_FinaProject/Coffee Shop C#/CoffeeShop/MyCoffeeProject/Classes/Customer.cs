﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCoffeeProject.Classes
{
    class Customer
    {
        //Instance variables. You refernce with THIS. Values change with different customer objects. 
       
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        //public string favCoffee { get; set; }
        //test
        private string _favCoffee;

        public string FavCoffee
        {
            get
            {
                return _favCoffee;
            }

            set
            {
                _favCoffee = value;
            }
        }

        //another way to set/ get
        private string phoneNumber;
        public string PhoneNumber
        {
            set { phoneNumber = value; }
            get { return phoneNumber; }
        }
       




     
        private int _custId;

        //set
        public void setId(int id)
        {
            if (id <= 0)
            {
                throw new Exception("ID cant be negative number");
            }
            //set
            this._custId = id;
        }

        //get
        public int getId()
        {
            return this._custId;
        }

    
        public  const double FEE = .3;

  
        public Customer( string F, string L,  string phone, string fCoffee)
        {
            Firstname = F;
            Lastname = L;
            _favCoffee = fCoffee;
            PhoneNumber = phone;
           
        }
        public string DisplayCustomer()
        {
            return "Name "+this.Firstname + " Order No:" + this.Lastname + " " + " Bill: " + this.phoneNumber + Environment.NewLine + "Coffee: " + this._favCoffee;
        }
        public string GetFullName()
        {
            return this.Firstname + " " + this.Lastname;
        }
        public double getFee()
        {
            return FEE;
        }
    }
}
